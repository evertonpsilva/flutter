import 'package:app_gestao/pages/gestor_home.dart';
import 'package:app_gestao/pages/home_dash.dart';
import 'package:app_gestao/pages/indicador_home.dart';
import 'package:app_gestao/pages/prevmais_home.dart';
import 'package:app_gestao/pages/siprev_home.dart';
import '../pages.dart';


import 'package:flutter/material.dart';
import 'dart:async';

class ControleRota extends StatefulWidget {
  @override
  _ControleRotaState createState() => _ControleRotaState();
}

class _ControleRotaState extends State<ControleRota> {
  var logado = true;
  @override
  Widget build(BuildContext context) {
    if(logado == true){
      return Inicio();
    }else{
      return PaginaLogin();
    }
  }
}

class PaginaLogin extends StatefulWidget {
  @override
  _PaginaLoginState createState() => _PaginaLoginState();
}


class _PaginaLoginState extends State<PaginaLogin> {


  bool iniciado = false;

  void iniciar(){
    
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(const Duration(seconds: 1), (){
      setState(() {
        iniciado = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF233645),
      appBar: null,
      body: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            AnimatedOpacity(
              opacity: iniciado ? 1.0 : 0.0,
              duration: Duration(milliseconds: 800),
              child: Container(
                height: MediaQuery.of(context).size.height * 0.3,
                child: Image.network("http://previcrato.com.br/wp-content/uploads/2019/06/logo-branca-3it.png", width: 140,),
              ),
            ),
            AnimatedContainer(
              duration: Duration(milliseconds: 900),
              curve: Curves.ease,
              height: iniciado ? MediaQuery.of(context).size.height * 0.7 : MediaQuery.of(context).size.height * 0.05,
              child: Container(
                height: MediaQuery.of(context).size.height * 0.7,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(40),
                    topRight: Radius.circular(40)
                  )
                ),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Padding(
                        child: Text("Bem-vindo",style: TextStyle(color: Color(0xFF233645), fontWeight: FontWeight.w600, fontSize: 26),textAlign: TextAlign.start,),
                        padding: EdgeInsets.fromLTRB(30, 60, 0, 30),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(30, 0, 30, 30),
                        child: TextField(
                          decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Color(0xFF233645), width: 1.5),
                              borderRadius: BorderRadius.circular(50)
                            ),
                            hintText: "Usuário",
                            hintStyle: TextStyle(
                              color: Color(0xFF233645)
                            ),
                            prefixIcon: Icon(Icons.person, color: Color(0xFF233645)),
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.fromLTRB(30, 0, 30, 40),
                        child: TextField(
                          obscureText: true,
                          decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Color(0xFF233645), width: 1.5),
                              borderRadius: BorderRadius.circular(50)
                            ),
                            hintText: "Senha",
                            hintStyle: TextStyle(color: Color(0xFF233645)),
                            prefixIcon: Icon(Icons.vpn_key,color: Color(0xFF233645))
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Padding(
                          padding: EdgeInsets.only(right: 30),
                          child: RaisedButton(
                            onPressed: (){},
                            child: Text("ENTRAR", style: TextStyle(fontSize: 18),),
                            padding: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                          ),
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.only(top: 65),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text("Problemas com login?"),
                            FlatButton(
                              child: Text("Entre em contato", style: TextStyle(color: Color(0xFF233645)),),
                              onPressed: (){},
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                )
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class Inicio extends StatefulWidget {
  @override
  _InicioState createState() => _InicioState();
}

class _InicioState extends State<Inicio> {

  int paginaAtual = 0;

  List<Widget> paginas = [
    HomeDash(),
    SiprevHome(),
    PrevmaisHome(),
    IndicadorHome(),
    GestorHome(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF233645),
        title: Text("Gestão - 3IT", style: TextStyle(color: Colors.white),),
        centerTitle: true,
        elevation: 0,
      ),
      body: paginas[paginaAtual],
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Color(0xFF233645),
        type: BottomNavigationBarType.fixed,
        currentIndex: paginaAtual,
        unselectedItemColor: Colors.white38,
        onTap: (int index){
          setState(() {
            paginaAtual = index;
          });
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            title: Text("Início"),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            title: Text("SIPREV"),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add),
            title: Text("Prev+"),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.check),
            title: Text("ISP"),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            title: Text("Gestor"),
          ),
        ],
      ),
    );
  }
}
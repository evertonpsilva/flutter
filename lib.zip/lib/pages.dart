import 'package:flutter/material.dart';

import './pages/home_dash.dart';
import './pages/gestor_home.dart';
import './pages/indicador_home.dart';
import './pages/prevmais_home.dart';
import './pages/siprev_home.dart';
import './controller/route_controller.dart';

const String rotaPrincipal = "/RotaPrincipal";
const String rotaHome = "/";
const String rotaSiprev = "/Siprev";
const String rotaIndicador = "/Indicador";
const String rotaPrevMais = "/Prevmais";
const String rotaGestor = "/Gestor";

class Router{
  Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {       
      case rotaPrincipal:
        return MaterialPageRoute(builder: (_) => ControleRota());
      case rotaHome:
        return MaterialPageRoute(builder: (_) => HomeDash());
      case rotaSiprev:
        return MaterialPageRoute(builder: (_) => SiprevHome());
      case rotaIndicador:
        return MaterialPageRoute(builder: (_) => IndicadorHome());
      case rotaPrevMais:
        return MaterialPageRoute(builder: (_) => PrevmaisHome());
      case rotaGestor:
        return MaterialPageRoute(builder: (_) => GestorHome());
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(
              child: Text('No route defined for ${settings.name}')),
          ));
    }
  }
  
}
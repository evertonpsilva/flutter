import 'package:flutter/material.dart';
import './controller/route_controller.dart';
import 'pages.dart';

void main() => runApp(
  MaterialApp(
    theme: ThemeData(
      fontFamily: "Montserrat",
      accentColor: Color(0xFF233645),
      primaryColor: Colors.white,
      buttonTheme: ButtonThemeData(
        buttonColor: Color(0xFF233645), 
        textTheme: ButtonTextTheme.primary,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
        padding: EdgeInsets.symmetric(horizontal: 0)
      ),
    ),
    home: ControleRota(),
    title: "Gestão  - 3IT Consultoria",
  ),
);


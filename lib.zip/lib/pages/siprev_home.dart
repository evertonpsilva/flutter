import 'package:flutter/material.dart';


class SiprevHome extends StatefulWidget{
  @override
  _SiprevHomeState createState() => _SiprevHomeState();
}

class _SiprevHomeState extends State<SiprevHome>{
  

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Color(0xFF233645),
      child: Column(
        children: <Widget>[
          DefaultTabController(
            length: 7,
            child: Expanded(
              child: Container(
                child: Column(
                  children: <Widget>[
                    TabBar(
                      indicatorColor: Colors.white,
                      labelColor: Colors.white,
                      
                      isScrollable: true,
                      tabs: <Widget>[
                        Tab(
                          text: "tab1",
                        ),
                        Tab(
                          text: "tab2",
                        ),
                        Tab(
                          text: "tab3",
                        ),
                        Tab(
                          text: "tab4",
                        ),
                        Tab(
                          text: "tab5",
                        ),
                        Tab(
                          text: "tab6",
                        ),
                        Tab(
                          text: "tab7",
                        )
                      ],
                    ),
                    Expanded(
                      child: TabBarView(
                        children: <Widget>[
                          Container(
                            color: Colors.green,
                          ),
                          Container(
                            color: Colors.yellow,
                          ),
                          Container(
                            color: Colors.grey,
                          ),
                          Container(
                            color: Colors.pink,
                          ),
                          Container(
                            color: Colors.black,
                          ),
                          Container(
                            color: Colors.blue,
                          ),
                          Container(
                            color: Colors.red,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';

class IndicadorHome extends StatefulWidget {
  @override
  _IndicadorHomeState createState() => _IndicadorHomeState();
}

class _IndicadorHomeState extends State<IndicadorHome> {
  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}
import 'package:flutter/material.dart';
import '../widgets/graficos.dart';

class HomeDash extends StatefulWidget {
  @override
  _HomeDashState createState() => _HomeDashState();
}

class _HomeDashState extends State<HomeDash> {

  var dadosPrevisao = [
    GraficosPorMes('2019',47, Color(0xFF233645)),
    GraficosPorMes('FEV',71, Color(0xFF233645)),
    GraficosPorMes('MAR',36, Color(0xFF233645)),
    GraficosPorMes('ABR',91, Color(0xFF233645)),
    GraficosPorMes('MAI',46, Color(0xFF233645)),
    GraficosPorMes('JUN',67, Color(0xFF233645)),
    GraficosPorMes('JUL',47, Color(0xFF233645)),
    GraficosPorMes('AGO',27, Color(0xFF233645)),
    GraficosPorMes('SET',51, Color(0xFF233645)),
    GraficosPorMes('OUT',71, Color(0xFF233645)),
    GraficosPorMes('NOV',52, Color(0xFF233645)),
    GraficosPorMes('DEZ',47, Color(0xFF233645)),
  ];

  final PageController pageController = PageController(initialPage: 0, viewportFraction: 0.9);
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        color: Colors.grey[100],
        child: Column(
          children: <Widget>[
            Stack(
              children: <Widget>[
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    height: 140,
                    width: MediaQuery.of(context).size.width,
                    color:Color(0xFF233645),
                  ),
                ),
                Container(
                  height: 160.0,
                  width: MediaQuery.of(context).size.width,
                  margin: EdgeInsets.symmetric(vertical: MediaQuery.of(context).size.width * 0.05),
                  child: PageView(
                    controller: pageController,
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.only(right: 5),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(0)
                        ),
                        child: Column(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: <Widget>[
                                  Text("Efetivos", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 17),),
                                  Container(
                                    padding: EdgeInsets.symmetric(horizontal: 5,vertical: 5),
                                    decoration: BoxDecoration(
                                      color: Colors.green,
                                      borderRadius: BorderRadius.circular(3)
                                    ),
                                    child: Text("Ativos", style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500,color: Colors.white),),
                                  )
                                ],
                              ),
                              decoration: BoxDecoration(
                                border: Border(
                                  bottom: BorderSide(
                                    color: Colors.grey
                                  ),
                                )
                              ),
                            ),
                            Container(
                              padding: EdgeInsets.symmetric(vertical: 20, horizontal: 15),
                              child: Column(
                                children: <Widget>[
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: <Widget>[
                                          GestureDetector(
                                            child: Text("2477", style: TextStyle(fontSize: 26, fontWeight: FontWeight.w500),),
                                            onTap: (){
                                              Navigator.push(context, MaterialPageRoute(builder: (context) => DetalheVinculo("Efetivos",12)));
                                            },
                                          ),
                                          Text("Vínculos Efetivos", style: TextStyle(fontSize: 17),)
                                        ],
                                      ),
                                      Text("84,65%")
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(color: Colors.red,margin: EdgeInsets.only(right: 5, left: 5)),
                      Container(color: Colors.blue,margin: EdgeInsets.only(left: 5)),
                    ],
                  ),
                ),
              ],
            ),
            Text("Previsão de Aposentadoria"),
            GraficoAnosMeses(),
          ],
        ),
      ),
    );
  }
}


class DetalheVinculo extends StatelessWidget {

  String tipo;
  int id;
  DetalheVinculo(this.tipo,this.id);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Detalhes ${tipo}", style: TextStyle(color: Colors.white),),
        backgroundColor: Color(0xFF233645),
        iconTheme: IconThemeData(
          color: Colors.white
        ),
      ),
      body: SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height,
          child: ListView.builder(
            itemCount: 6,
            scrollDirection: Axis.vertical,
            itemBuilder: (context, index){
              return Container(
                color: index%2==0 ? Colors.white : Colors.grey[200],
                child: ExpansionTile(
                  title: Text("Antonio"),
                  children: <Widget>[
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Padding(
                          child: Text("CPF: 195.773.033-15"),
                          padding: EdgeInsets.only(left: 15, bottom: 5),
                        ),
                        Padding(
                          child: Text("Idade: 56 Anos"),
                          padding: EdgeInsets.only(right: 15, bottom: 5),
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Padding(
                          child: Text("Matrícula: 177"),
                          padding: EdgeInsets.only(left: 15, top: 5, bottom: 20),
                        ),
                        Padding(
                          child: Text("Cargo: ODONTOLOGO"),
                          padding: EdgeInsets.only(right: 15, top: 5, bottom: 20),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
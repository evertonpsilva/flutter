import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:bubble_tab_indicator/bubble_tab_indicator.dart';


class GraficosPorMes{
  String mes;
  int valor;
  final charts.Color cor;
  GraficosPorMes(this.mes,this.valor, Color cor): this.cor = new charts.Color(
            r: cor.red, g: cor.green, b: cor.blue, a: cor.alpha);
}

class GraficosMeses extends StatefulWidget {

  bool mostraDados;
  List<GraficosPorMes> dadoAnos;
  GraficosMeses(this.dadoAnos,this.mostraDados);

  @override
  _GraficosMesesState createState() => _GraficosMesesState();
}

class _GraficosMesesState extends State<GraficosMeses> {
  
  bool segundoSemestre = false;
  var dados1Semestre;
  var dados2Semestre;

  @override
  void initState(){
    super.initState();
    print(widget.dadoAnos.length);
    if(widget.dadoAnos.length>6){
      dados1Semestre = [
        widget.dadoAnos[0],
        widget.dadoAnos[1],
        widget.dadoAnos[2],
        widget.dadoAnos[3],
        widget.dadoAnos[4],
        widget.dadoAnos[5],
      ];
      dados2Semestre = [
        widget.dadoAnos[6],
        widget.dadoAnos[7],
        widget.dadoAnos[8],
        widget.dadoAnos[9],
        widget.dadoAnos[10],
        widget.dadoAnos[11],
      ];
    }else{

    }
  }
  _onSelectionChanged(charts.SelectionModel model) {
    final selectedModel = model.selectedDatum.first.datum.mes;
    print(selectedModel);

    Navigator.push(context, MaterialPageRoute(builder: (context) => DetalheMes(selectedModel)));
  }
  @override
  Widget build(BuildContext context) {
    var series = [
      new charts.Series(
        id: 'Grafico por meses',
        domainFn: (GraficosPorMes dadosMeses, _) => dadosMeses.mes,
        measureFn: (GraficosPorMes dadosValores, _) => dadosValores.valor,
        colorFn: (GraficosPorMes dadosCores, _) => dadosCores.cor,
        data: widget.dadoAnos,
        labelAccessorFn: (GraficosPorMes dadosValores, _) => '${dadosValores.valor}',
      ),
    ];
    if(widget.dadoAnos.length > 6){
      series = [
        new charts.Series(
          id: 'Grafico por meses',
          domainFn: (GraficosPorMes dadosMeses, _) => dadosMeses.mes,
          measureFn: (GraficosPorMes dadosValores, _) => dadosValores.valor,
          colorFn: (GraficosPorMes dadosCores, _) => dadosCores.cor,
          data: segundoSemestre ? dados2Semestre : dados1Semestre,
          labelAccessorFn: (GraficosPorMes dadosValores, _) => '${dadosValores.valor}',
        ),
      ];
    }
    var chart = new charts.BarChart(
      series,
      animate: true,
      barRendererDecorator: charts.BarLabelDecorator<String>(),
      selectionModels: [
        charts.SelectionModelConfig(
          type: charts.SelectionModelType.info,
          changedListener: widget.mostraDados ? _onSelectionChanged : null,
        )
      ],
    );
    var chartWidget = new Padding(
      padding: new EdgeInsets.symmetric(horizontal: 32.0, vertical: 15.0),
      child: new SizedBox(
        height: 200.0,
        child: chart,
      ),
    );
    List<Widget> botoesSemestres;
    if(widget.dadoAnos.length > 6){
      botoesSemestres = <Widget>[
        RaisedButton(
          padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
          child: Text("1º Semestre"),
          onPressed: !segundoSemestre ? null :  (){
            setState(() {
              segundoSemestre = false;
              print("1sem");
            });
          },
        ),
        RaisedButton(
          padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
          child: Text("2º Semestre"),
          onPressed: segundoSemestre ? null : (){
            setState(() {
              segundoSemestre = true;
              print("2sem");
            });
          },
        ),
      ];
    }else{
      botoesSemestres = <Widget>[];
    }
    return Column(
      children: <Widget>[
        Container(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: botoesSemestres,
          ),
        ),
        chartWidget
      ],
    );
  }
}


class GraficoAnosMeses extends StatefulWidget {
  @override
  _GraficoAnosMesesState createState() => _GraficoAnosMesesState();
}

class _GraficoAnosMesesState extends State<GraficoAnosMeses> with TickerProviderStateMixin{

  int anoAtual = 2;
  PageController graficoAnoCon = PageController(
    initialPage: 2,
    viewportFraction: 1,
  );

  static var dadoCompleto2017 = [
    GraficosPorMes('2019',47, Color(0xFF233645)),
    GraficosPorMes('FEV',71, Color(0xFF233645)),
    GraficosPorMes('MAR',36, Color(0xFF233645)),
    GraficosPorMes('ABR',91, Color(0xFF233645)),
    GraficosPorMes('MAI',46, Color(0xFF233645)),
    GraficosPorMes('JUN',67, Color(0xFF233645)),
    GraficosPorMes('JUL',47, Color(0xFF233645)),
    GraficosPorMes('AGO',27, Color(0xFF233645)),
    GraficosPorMes('SET',51, Color(0xFF233645)),
    GraficosPorMes('OUT',71, Color(0xFF233645)),
    GraficosPorMes('NOV',52, Color(0xFF233645)),
    GraficosPorMes('DEZ',47, Color(0xFF233645)),
  ];
  static var dadoCompleto2018 = [
    GraficosPorMes('JAN',47, Color(0xFF233645)),
    GraficosPorMes('FEV',71, Color(0xFF233645)),
    GraficosPorMes('MAR',36, Color(0xFF233645)),
    GraficosPorMes('ABR',91, Color(0xFF233645)),
    GraficosPorMes('MAI',46, Color(0xFF233645)),
    GraficosPorMes('JUN',67, Color(0xFF233645)),
    GraficosPorMes('JUL',47, Color(0xFF233645)),
    GraficosPorMes('AGO',27, Color(0xFF233645)),
    GraficosPorMes('SET',51, Color(0xFF233645)),
    GraficosPorMes('OUT',71, Color(0xFF233645)),
    GraficosPorMes('NOV',52, Color(0xFF233645)),
    GraficosPorMes('DEZ',47, Color(0xFF233645)),
  ];
  static var dadoCompleto2019 = [
    GraficosPorMes('JAN',47, Color(0xFF233645)),
    GraficosPorMes('FEV',71, Color(0xFF233645)),
  ];

  @override
  Widget build(BuildContext context) {
    TabController graficosCon = TabController(
      initialIndex: 0,
      length: 3,
      vsync: this,
    );
    return Container(
      child: Column(
        children: <Widget>[
          Container(
            margin: EdgeInsets.only(left: MediaQuery.of(context).size.width * 0.05),
            child: DefaultTabController(
                length: 3,
                child: TabBar(
                  controller: graficosCon,
                  indicatorSize: TabBarIndicatorSize.tab,
                  labelColor: Colors.white,
                  unselectedLabelColor: Color(0xFF233645),
                  indicator: new BubbleTabIndicator(
                    indicatorHeight: 25.0,
                    indicatorColor: Color(0xFF233645),
                    tabBarIndicatorSize: TabBarIndicatorSize.tab,
                  ),
                  tabs: <Widget>[
                    Tab(
                      child: Text("2019"),
                    ),
                    Tab(
                      child: Text("2018"),
                    ),
                    Tab(
                      child: Text("2017"),
                    ),
                  ],
                ),
            ),
          ),
          Container(
            height: 315,
            width: MediaQuery.of(context).size.width,
            child: TabBarView(
              physics: NeverScrollableScrollPhysics(),
              controller: graficosCon,
              children: <Widget>[
                  GraficosMeses(dadoCompleto2019,true,),
                  GraficosMeses(dadoCompleto2018,true,),
                  GraficosMeses(dadoCompleto2017,true,),
              ],
            ),
          ),
          Text("asdasd"),
        ],
      ),  
    );
  }
}

class DetalheMes extends StatelessWidget {
  String mes;
  DetalheMes(this.mes);
  String mesComp;
  @override
  Widget build(BuildContext context) {
    if(mes == "JAN"){
      mesComp = "Janeiro";
    }else if(mes == "FEV"){
      mesComp = "Fevereiro";
    }else if(mes == "FEV"){
      mesComp = "Fevereiro";
    }else if(mes == "ABR"){
      mesComp = "Abril";
    }else if(mes == "MAI"){
      mesComp = "Maio";
    }else if(mes == "JUN"){
      mesComp = "Junho";
    }else if(mes == "JUL"){
      mesComp = "Julho";
    }else if(mes == "AGO"){
      mesComp = "Agosto";
    }else if(mes == "SET"){
      mesComp = "Setembro";
    }else if(mes == "OUT"){
      mesComp = "Outubro";
    }else if(mes == "NOV"){
      mesComp = "Novembro";
    }else if(mes == "DEZ"){
      mesComp = "Dezembro";
    }
    return Scaffold(
      appBar: AppBar(
        title: Text("Detalhes ${mesComp}/2019"),
      ),
      body: Container(
        child: Text("Mês de ${mesComp} de 2019"),
      ),
    );
  }
}